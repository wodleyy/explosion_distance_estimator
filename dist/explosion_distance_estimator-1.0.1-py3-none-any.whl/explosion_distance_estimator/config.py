# Default settings
DEFAULT_LAT = 50.4501  # Kyiv
DEFAULT_LON = 30.5234
DEFAULT_DATE_OFFSET_DAYS = 0

VIDEO_PATH = 'test_explosion.mp4'
AUDIO_PATH = 'explosion_audio.wav'
FRAMES_DIR = 'frames'
LOG_FILE = 'log.csv'
