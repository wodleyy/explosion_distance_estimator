# Explosion Distance Estimator

Install this package locally with:

```bash
pip install .
```

Then run:

```bash
explosion-distance-estimator --help
```
